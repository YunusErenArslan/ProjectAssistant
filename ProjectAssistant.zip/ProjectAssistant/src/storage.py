import os, json, uuid, time
from typing import List, Dict, Any, Optional
import config

class ConversationStore:
    def __init__(self, path: str = None):
        self.path = path or config.CONV_STORE_PATH
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        if not os.path.exists(self.path):
            self._write({"threads": []})
        self._data = self._read()

    def _read(self) -> Dict[str, Any]:
        with open(self.path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _write(self, data: Dict[str, Any]) -> None:
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def list_threads(self) -> List[Dict[str, Any]]:
        self._data = self._read()
        threads = self._data.get("threads", [])
        threads.sort(key=lambda x: x.get("updated_at", 0), reverse=True)
        return threads

    def new_thread(self, title: str = None) -> str:
        thread_id = str(uuid.uuid4())
        now = int(time.time())
        thread = {
            "id": thread_id,
            "title": title or f"Sohbet {time.strftime('%Y-%m-%d %H:%M')}",
            "messages": [],
            "created_at": now,
            "updated_at": now,
        }
        self._data = self._read()
        self._data["threads"].append(thread)
        self._write(self._data)
        return thread_id

    def add_message(self, thread_id: str, role: str, content: str) -> None:
        self._data = self._read()
        for t in self._data.get("threads", []):
            if t["id"] == thread_id:
                t["messages"].append({"role": role, "content": content, "ts": int(time.time())})
                t["updated_at"] = int(time.time())
                self._write(self._data)
                return
        raise KeyError(f"Thread not found: {thread_id}")

    def get_thread(self, thread_id: str) -> Optional[Dict[str, Any]]:
        self._data = self._read()
        for t in self._data.get("threads", []):
            if t["id"] == thread_id:
                return t
        return None

    def set_title_if_empty(self, thread_id: str, user_text: str, max_words: int = None) -> None:
        max_words = max_words or 10
        self._data = self._read()
        for t in self._data.get("threads", []):
            if t["id"] == thread_id and (not t.get("title") or t["title"].startswith("Sohbet ")):
                words = (user_text or "").strip().split()
                short = " ".join(words[:max_words]) if words else t["title"]
                t["title"] = short if short else t["title"]
                self._write(self._data)
                return

    def delete_thread(self, thread_id: str) -> None:
        self._data = self._read()
        self._data["threads"] = [t for t in self._data.get("threads", []) if t["id"] != thread_id]
        self._write(self._data)
