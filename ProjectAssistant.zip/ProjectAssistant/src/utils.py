import os, re, uuid, pickle
from typing import List, Any

def ensure_dirs(*paths: str) -> None:
    for p in paths:
        os.makedirs(p, exist_ok=True)

def slugify(text: str, max_len: int = 60) -> str:
    s = re.sub(r"\s+", " ", text or "").strip()
    s = s.replace("/", "-").replace("\\", "-")
    s = re.sub(r"[^a-zA-Z0-9çÇğĞıİöÖşŞüÜ\-\s]", "", s)
    s = re.sub(r"\s+", "-", s)
    return s[:max_len] if s else str(uuid.uuid4())

def chunk_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    if not text:
        return []
    if len(text) <= chunk_size:
        return [text]
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        start = end - overlap
        if start < 0:
            start = 0
        if start >= len(text):
            break
    return chunks

def save_pickle(obj: Any, path: str) -> None:
    with open(path, "wb") as f:
        pickle.dump(obj, f)

def load_pickle(path: str) -> Any:
    with open(path, "rb") as f:
        return pickle.load(f)
