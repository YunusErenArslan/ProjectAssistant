import os, pickle
from typing import List, Dict, Any, Tuple
import numpy as np
import pandas as pd
import faiss
from sentence_transformers import SentenceTransformer
import config
from .utils import chunk_text, save_pickle, load_pickle

def _normalize(v: np.ndarray) -> np.ndarray:
    v = v.astype(np.float32)
    n = np.linalg.norm(v, axis=1, keepdims=True) + 1e-12
    return (v / n).astype(np.float32)

def _load_embedder() -> SentenceTransformer:
    model_path = config.EMBED_MODEL_PATH
    if not os.path.isdir(model_path):
        raise RuntimeError(
            f"Embedding modeli bulunamadı: {model_path}.\n"
            f"Lütfen paraphrase-multilingual-MiniLM-L12-v2 klasörünü Embedding/ içine yerleştirin."
        )
    return SentenceTransformer(model_path)

# Excel'i esnek sütun adlarıyla okuyup içerikleri döndürür
def _read_project_excel(xlsx_path: str) -> Dict[str, Any]:
    name = os.path.splitext(os.path.basename(xlsx_path))[0]
    try:
        df = pd.read_excel(xlsx_path)
    except Exception:
        return {"name": name, "konular": [], "tarihler": [], "notlar": [], "durum": "", "xlsx": xlsx_path}
    cols = [str(c).strip() for c in df.columns.astype(str).tolist()]
    konu_col  = next((c for c in cols if "Konusu" in c or "Toplantı Konusu" in c or c.lower().startswith("konu")), None)
    tarih_col = next((c for c in cols if "Tarih" in c), None)
    not_col   = next((c for c in cols if "Not" in c), None)
    durum_col = next((c for c in cols if "Durum" in c), None)

    def _col_vals(col):
        if not col or col not in df.columns: return []
        vals = pd.Series(df[col]).astype(str).fillna("").tolist()
        vals = [v.strip() for v in vals if v and str(v).strip() and str(v).strip().lower() != "nan"]
        # 'GG.AA.YYYY | ... | ...' gibi hücreleri satır içi ayır
        out = []
        for v in vals:
            if "|" in v:
                parts = [p.strip() for p in v.split("|") if p.strip()]
                out.extend(parts)
            else:
                out.append(v)
        # Tekilleştir, sıralı koru
        seen = set(); uniq = []
        for v in out:
            if v not in seen:
                uniq.append(v); seen.add(v)
        return uniq

    konular  = _col_vals(konu_col)
    tarihler = _col_vals(tarih_col)
    notlar   = _col_vals(not_col)
    durum    = ""
    if durum_col and durum_col in df.columns:
        s = pd.Series(df[durum_col]).astype(str)
        s = s[s.str.strip().ne("") & s.str.lower().ne("nan")]
        if not s.empty:
            try:
                durum = s.mode().iloc[0]
            except Exception:
                durum = s.iloc[0]

    # Proje dokümanları (varsa): data/Proje Dokümanları/<Proje Adı>/*
    docs_dir = os.path.join(config.PROJE_DOKUMANLARI_DIR, name)
    dokumanlar = []
    if os.path.isdir(docs_dir):
        for fn in sorted(os.listdir(docs_dir)):
            p = os.path.join(docs_dir, fn)
            if os.path.isfile(p):
                dokumanlar.append(fn)

    return {
        "name": name,
        "konular": konular,
        "tarihler": tarihler,
        "notlar": notlar,
        "durum": durum,
        "dokumanlar": dokumanlar,
        "xlsx": xlsx_path,
    }

# Projeler klasöründeki tüm excellerden metin belgeleri üretir
def _build_docs_from_projelers() -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    projeler = []
    if os.path.isdir(config.PROJELER_DIR):
        for fn in sorted(os.listdir(config.PROJELER_DIR)):
            if not fn.lower().endswith(".xlsx"): 
                continue
            projeler.append(_read_project_excel(os.path.join(config.PROJELER_DIR, fn)))

    docs: List[Dict[str, Any]] = []
    meta: List[Dict[str, Any]] = []
    for p in projeler:
        lines = [f"PROJE: {p['name']}"]
        if p.get("durum"):
            lines.append(f"PROJE DURUMU: {p['durum']}")
        if p.get("konular"):
            lines.append("TOPLANTI KONULARI:")
            for k in p["konular"]:
                lines.append(f"- {k}")
        if p.get("tarihler"):
            lines.append("TOPLANTI TARİHLERİ:")
            for t in p["tarihler"]:
                lines.append(f"- {t}")
        if p.get("notlar"):
            lines.append("TOPLANTI NOTLARI:")
            for n in p["notlar"]:
                lines.append(f"- {n}")
        if p.get("dokumanlar"):
            lines.append("DOKÜMANLAR:")
            for d in p["dokumanlar"]:
                lines.append(f"- {d}")

        # --- Konu -> Notlar eşlemesi (tekrarları koru) ---
        topic_to_notes = {}
        try:
            import pandas as pd, re as _re
            df = pd.read_excel(p["xlsx"])
            cols = [str(c).strip() for c in df.columns.astype(str).tolist()]
            konu_col  = next((c for c in cols if "Konusu" in c or "Toplantı Konusu" in c or c.lower().startswith("konu")), None)
            not_col   = next((c for c in cols if "Not" in c), None)

            def _split_tokens(val):
                toks = []
                s = str(val) if val is not None else ""
                s = s.strip()
                if not s or s.lower() == "nan":
                    return toks
                for part in _re.split(r"\|\s*|\n|[,;]\s*", s):
                    part = part.strip()
                    if part and part.lower() != "nan":
                        toks.append(part)
                return toks

            if konu_col and not_col and konu_col in df.columns and not_col in df.columns:
                for _, row in df.iterrows():
                    topics = _split_tokens(row.get(konu_col))
                    notes  = _split_tokens(row.get(not_col))
                    if not topics or not notes:
                        continue
                    for t in topics:
                        if t not in topic_to_notes:
                            topic_to_notes[t] = []
                        # Tekrarları da sakla
                        for n in notes:
                            topic_to_notes[t].append(n)
        except Exception:
            topic_to_notes = {}

        if topic_to_notes:
            lines.append("KONUYA GÖRE NOTLAR:")
            for topic, notes_list in topic_to_notes.items():
                lines.append(f"* {topic}")
                for n in notes_list:
                    lines.append(f"  - {n}")

        text = "\n".join(lines).strip()
        if not text:
            continue

        chunks = [text] if len(text) < config.MIN_CHARS_TO_CHUNK else chunk_text(text, config.CHUNK_SIZE, config.CHUNK_OVERLAP)
        for ch in chunks:
            docs.append(ch)
            meta.append({
                "project": p["name"],
                "text": ch,
                "durum": p.get("durum", ""),
                "source": p.get("xlsx", ""),
            })
    return docs, meta


# FAISS indeksini yükler ya da Projeler verisinden yeniden oluşturur
def build_or_load_faiss(rebuild: bool = False) -> Tuple[Any, List[Dict[str, Any]]]:
    os.makedirs(config.VECTOR_DIR, exist_ok=True)
    idx_path = config.FAISS_INDEX_PATH
    meta_path = config.FAISS_META_PATH

    if (not rebuild) and os.path.exists(idx_path) and os.path.exists(meta_path):
        try:
            index = faiss.read_index(idx_path)
            meta = load_pickle(meta_path)
            if index is not None and isinstance(meta, list) and meta:
                return index, meta
        except Exception:
            pass  # yeniden inşa et

    # Yeniden inşa
    docs, meta = _build_docs_from_projelers()
    if not docs:
        return None, None

    embedder = _load_embedder()
    emb = embedder.encode([d for d in docs], convert_to_numpy=True, show_progress_bar=False)
    emb = _normalize(emb)

    d = emb.shape[1]
    index = faiss.IndexFlatIP(d)
    index.add(emb.astype(np.float32))

    faiss.write_index(index, idx_path)
    save_pickle(meta, meta_path)
    return index, meta

# Sorguya göre en alakalı metin parçalarını döndürür
def search(query: str, top_k: int = None) -> List[Dict[str, Any]]:
    top_k = top_k or config.TOP_K
    index, meta = build_or_load_faiss(rebuild=False)
    if not index or not meta:
        return []
    embedder = _load_embedder()
    q = embedder.encode([query], convert_to_numpy=True)
    q = _normalize(q)
    D, I = index.search(q, top_k)
    hits = []
    for idx in I[0]:
        if idx < 0 or idx >= len(meta):
            continue
        hits.append(meta[idx])
    return hits

# Yeni bir proje eklendiğinde indeksi Projeler klasöründen yeniden kurar
def add_project_and_update_index(*_args, **_kwargs) -> None:
    build_or_load_faiss(rebuild=True)
