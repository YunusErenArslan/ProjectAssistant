import re
import os
from pathlib import Path
from typing import List
import streamlit as st
import pandas as pd
import config

DOCS_ROOT = Path(config.PROJE_DOKUMANLARI_DIR)

def ensure_structure(df: pd.DataFrame, project_col: str = "Proje Adı") -> None:
    """Sadece proje klasörlerini oluşturur; Excel'den doküman adı okumaz."""
    DOCS_ROOT.mkdir(exist_ok=True)
    for _, row in df.iterrows():
        proj = str(row.get(project_col, "")).strip() or "İsimsiz Proje"
        (DOCS_ROOT / proj).mkdir(exist_ok=True, parents=True)
    return None

def list_project_files(project_name: str) -> List[Path]:
    proj_dir = DOCS_ROOT / project_name
    if not proj_dir.exists():
        return []
    files = [p for p in proj_dir.iterdir() if p.is_file()]
    return sorted(files, key=lambda p: p.name.lower())

def render_docs_ui(project_name: str) -> None:
    # Başlık kaldırıldı — sadece liste + yükleme
    files = list_project_files(project_name)
    if not files:
        st.info("Bu proje için doküman bulunamadı.")
    else:
        for i, f in enumerate(files):
            with open(f, "rb") as fh:
                st.download_button(
                    label=f"İndir: {f.name}",
                    data=fh.read(),
                    file_name=f.name,
                    key=f"dl_{project_name}_{i}",
                    use_container_width=True
                )
    st.markdown("---")
    st.markdown("### Proje Doküman Ekleme")
    up = st.file_uploader("Yeni doküman yükle", key=f"uploader_{project_name}")
    if up is not None:
        proj_dir = DOCS_ROOT / project_name
        proj_dir.mkdir(exist_ok=True, parents=True)
        save_path = proj_dir / up.name
        with open(save_path, "wb") as out:
            out.write(up.getbuffer())
        st.success(f"{up.name} yüklendi.")
        st.rerun()
