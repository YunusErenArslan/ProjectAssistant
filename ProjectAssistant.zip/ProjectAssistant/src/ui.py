import streamlit as st
import config

def sidebar_nav():
    # Sidebar: collapse gizle, sabit genişlik
    st.sidebar.markdown(
        """
        
        """, unsafe_allow_html=True
    )

    st.sidebar.markdown(f"### {config.APP_TITLE}")

    # Sekme benzeri, aynı boyutta iki buton
    c1, c2 = st.sidebar.columns(2, gap="small")
    b1 = c1.button(config.BOT_PAGE_TITLE, use_container_width=True)
    b2 = c2.button(config.CARDS_PAGE_TITLE, use_container_width=True)

    if "page" not in st.session_state:
        st.session_state.page = config.BOT_PAGE_TITLE

    if b1:
        st.session_state.page = config.BOT_PAGE_TITLE
        st.rerun()
    if b2:
        st.session_state.page = config.CARDS_PAGE_TITLE
        st.rerun()

def horizontal_rule():
    st.sidebar.markdown("---")



