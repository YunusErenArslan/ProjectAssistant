import json, requests
from typing import List, Dict, Generator
import config

def ollama_chat_stream(messages: List[Dict], model: str = None) -> Generator[str, None, None]:
    if model is None:
        model = config.OLLAMA_MODEL
    url = f"{config.OLLAMA_BASE_URL}/api/chat"
    payload = {"model": model, "messages": messages, "stream": True}
    try:
        with requests.post(url, json=payload, stream=True, timeout=600) as r:
            r.raise_for_status()
            for line in r.iter_lines():
                if not line:
                    continue
                try:
                    obj = json.loads(line.decode("utf-8"))
                except Exception:
                    continue
                if "message" in obj and "content" in obj["message"]:
                    yield obj["message"]["content"]
                if obj.get("done"):
                    break
    except requests.exceptions.RequestException as e:
        yield f"[LLM hatası: Ollama'a ulaşılamıyor. {str(e)}]"

def build_chat_messages(system_prompt: str, user_content: str) -> List[Dict]:
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]
