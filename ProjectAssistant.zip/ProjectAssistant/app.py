import os
import os, json, time
import streamlit as st
import re

import pandas as pd
import config
from src import ui
from src.storage import ConversationStore
from src import rag
from src import docs
from src import llm
from src.prompts import SYSTEM_PROMPT
import re as _re
from pathlib import Path
import numpy as np

import datetime as _dti
import pandas as _pdi

# İlk mesaj iş parçacığını oluşturduğunda sonsuz tekrarları önlemek için koruma bayrağı
if 'first_msg_rerun_done' not in st.session_state:
    st.session_state['first_msg_rerun_done'] = False

PROJELER_DIR = Path(config.PROJELER_DIR)

def _normalize_list_cell(val):
    if val is None:
        return []
    if isinstance(val, (list, tuple, set)):
        return [str(x).strip() for x in val if str(x).strip()]
    s = str(val).strip()
    if not s or s.lower() in ("nan","none"):
        return []
    # bölünmüş |, virgül, yeni satır              
    parts = re.split(r"[|,\n]+", s)
    return [p.strip() for p in parts if p.strip()]


# ---------------------------------
# Aylık Ajanda için toplantı kayıtları (satır bazlı) oluşturucu
# Her Excel satırından (Konu, Tarih, Durum) -> tekil kayıtlar

def build_meeting_records() -> list:
    """
    Tüm Projeler'deki Excel dosyalarını gezerek (Konu, Tarih, Durum) bazında
    tekil toplantı kayıtları çıkarır. Tarihleri güvenli şekilde parse eder.
    """

    TR_MONTHS = ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"]

    def _normalize_list_cell_local(val):
        if val is None:
            return []
        if isinstance(val, (list, tuple, set)):
            return [str(x).strip() for x in val if str(x).strip()]
        s = str(val).strip()
        if not s or s.lower() in ("nan","none"):
            return []
        parts = _re.split(r"[|,\n]+", s)
        return [p.strip() for p in parts if p.strip()]

    def _parse_date_token_local(s: str):
        s = str(s).strip()
        if not s:
            return None
        # Önce GG.AA.YYYY
        m1 = _re.match(r"^(\d{2})[./-](\d{2})[./-](\d{4})$", s)
        if m1:
            d, m, y = map(int, m1.groups())
            return (y, m, d)
        # Sonra YYYY-AA-GG
        m2 = _re.match(r"^(\d{4})[./-](\d{2})[./-](\d{2})$", s)
        if m2:
            y, m, d = map(int, m2.groups())
            return (y, m, d)
        # Pandas ile son çare
        try:
            ts = _pdi.to_datetime(s, dayfirst=True, errors="coerce")
            if _pdi.isna(ts):
                return None
            return (int(ts.year), int(ts.month), int(ts.day))
        except Exception:
            return None

    records = []
    pdir = Path(PROJELER_DIR) if not isinstance(PROJELER_DIR, Path) else PROJELER_DIR
    if not pdir.exists():
        return records

    for xlsx in sorted(pdir.glob("*.xlsx")):
        proj_name = xlsx.stem
        try:
            dfp = pd.read_excel(xlsx)
        except Exception:
            continue
        cols = [c.strip() for c in dfp.columns.astype(str).tolist()]
        konu_col  = next((c for c in cols if "Konusu" in c or "Toplantı Konusu" in c or c.lower().startswith("konu")), None)
        tarih_col = next((c for c in cols if "Tarih" in c), None)
        durum_col = next((c for c in cols if "Durum" in c), None)

        for _, r in dfp.iterrows():
            topic = str(r.get(konu_col, "")).strip() if konu_col else ""
            status = str(r.get(durum_col, "")).strip() if durum_col else ""
            dates_cell = r.get(tarih_col, None) if tarih_col else None
            for tok in _normalize_list_cell_local(dates_cell):
                parsed = _parse_date_token_local(tok)
                if not parsed:
                    continue
                y, m, d = parsed
                try:
                    date_obj = _dti.date(y, m, d)
                except Exception:
                    continue
                date_str = f"{d:02d}.{m:02d}.{y}"
                records.append({
                    "date": date_obj,
                    "date_str": date_str,
                    "month_name": TR_MONTHS[m-1],
                    "year": y,
                    "month": m,
                    "day": d,
                    "topic": topic or "Toplantı",
                    "project": proj_name,
                    "status": status or "",
                })
    return records

def build_projects_df() -> pd.DataFrame:
    rows = []
    for xlsx in sorted(PROJELER_DIR.glob("*.xlsx")):
        proj_name = xlsx.stem
        try:
            df = pd.read_excel(xlsx)
        except Exception:
            continue
        cols = [c.strip() for c in df.columns.astype(str).tolist()]
        # Esnek sütun adlarını eşleştir
        konu_col = next((c for c in cols if "Konusu" in c or "Toplantı Konusu" in c or c.lower().startswith("konu")), None)
        tarih_col = next((c for c in cols if "Tarih" in c), None)
        not_col = next((c for c in cols if "Not" in c), None)
        durum_col = next((c for c in cols if "Durum" in c), None)

        # Değerler: boş olmayan benzersiz girdileri topla
        konu_vals = []
        if konu_col and konu_col in df.columns:
            konu_vals = [str(x).strip() for x in df[konu_col].dropna().astype(str) if str(x).strip() and str(x).strip().lower() != "nan"]
        tarih_vals = []
        if tarih_col and tarih_col in df.columns:
            # liste benzeri dizeleri düzleştirin
            tmp = []
            for v in df[tarih_col].dropna().tolist():
                tmp.extend(_normalize_list_cell(v))
            tarih_vals = sorted(set(tmp))
        not_vals = []
        if not_col and not_col in df.columns:
            not_vals = [str(x).strip() for x in df[not_col].dropna().astype(str) if str(x).strip() and str(x).strip().lower() != "nan"]
        durum_val = ""
        if durum_col and durum_col in df.columns and len(df[durum_col].dropna())>0:
            # En sık kullanılan boş olmayan değeri seç
            s = df[durum_col].dropna().astype(str)
            s = s[s.str.strip()!=""]
            if len(s)>0:
                durum_val = s.mode().iloc[0] if not s.mode().empty else s.iloc[0]

        rows.append({
            "Proje Adı": proj_name,
            "Toplantı Konusu": " | ".join(sorted(set(konu_vals))) if konu_vals else "",
            "Toplantı Tarihleri": " | ".join(tarih_vals) if tarih_vals else "",
            "Toplantı Notları": "\\n- " + "\\n- ".join(not_vals) if not_vals else "",
            "Proje Durumu": durum_val,
            "_excel_path": str(xlsx)
        })
    return pd.DataFrame(rows)



# ============================
# PROJE EXCEL YARDIMCILARI
# ============================
import datetime

def _read_project_excel(xlsx_path: str) -> pd.DataFrame:
    try:
        df = pd.read_excel(xlsx_path)
    except Exception:
        df = pd.DataFrame()
    # Standart kolon adlarını yakala
    cols = [c.strip() for c in df.columns.astype(str).tolist()] if not df.empty else []
    konu_col  = next((c for c in cols if "konu" in c.lower()), "Toplantı Konusu")
    tarih_col = next((c for c in cols if "tarih" in c.lower()), "Toplantı Tarihleri")
    not_col   = next((c for c in cols if "not" in c.lower()), "Toplantı Notları")
    durum_col = next((c for c in cols if "durum" in c.lower()), "Proje Durumu")
    # Boşsa iskelet oluştur
    if df.empty:
        df = pd.DataFrame(columns=[konu_col, tarih_col, not_col, durum_col])
    return df, konu_col, tarih_col, not_col, durum_col

def _write_project_excel(xlsx_path: str, df: pd.DataFrame):
    # Var olan dosyanın üzerine yaz
    df.to_excel(xlsx_path, index=False)

def _normalize_notes_cell(val: str) -> list:
    if not isinstance(val, str):
        val = "" if pd.isna(val) else str(val)
    # Yer tutucu dizeleri de boş olarak değerlendirin
    if val.strip().lower() in ("nan","nat","none","null"):
        val = ""
    val = val.replace("\\r", "\\n")
    # Ayırıcılar: yeni satır veya ' - ' madde işareti
    parts = []
    for line in val.split("\\n"):
        t = line.strip()
        if not t:
            continue
        if t.startswith("- "):
            t = t[2:].strip()
        parts.append(t)
    return parts

def _join_notes(parts: list) -> str:
    parts = [str(p).strip() for p in parts if str(p).strip()]
    if not parts:
        return ""
    # Excelde anlaşılır dursun
    return "\\n" + "\\n".join(f"- {p}" for p in parts)

def _assert_can_add_date(df, tarih_col, konu_col) -> tuple[bool, str]:
    # En son satırda konu var mı?
    if df.empty or not str(df.iloc[-1].get(konu_col, "")).strip():
        return False, "Önce 'Toplantı Konusu' ekleyin."
    return True, ""

def _assert_can_add_note(df, tarih_col, konu_col) -> tuple[bool, str]:
    if df.empty or not str(df.iloc[-1].get(tarih_col, "")).strip():
        return False, "Önce 'Toplantı Tarihi' ekleyin."
    if not str(df.iloc[-1].get(konu_col, "")).strip():
        return False, "Önce 'Toplantı Konusu' ekleyin."
    return True, ""


def _compute_global_counts(df: pd.DataFrame) -> str:
    """Projeler için sayısal özet metni döndürür (LLM bağlamı için)."""
    try:
        total_projects = len([p for p in PROJELER_DIR.glob("*.xlsx")])
    except Exception:
        total_projects = len(df) if df is not None else 0
    status_col = next((c for c in df.columns if "Durum" in str(c)), None) if df is not None else None
    c_done = c_cancel = c_prog = 0
    if df is not None and status_col and status_col in df.columns:
        s = df[status_col].astype(str).fillna("")
        c_done   = int((s == "Tamamlandı").sum())
        c_cancel = int((s == "İptal Edildi").sum())
        c_prog   = int((s == "Devam Ediyor").sum())
    # Kısa ve net bir özet
    summary = (
        f"- [Özet] Toplam proje (xlsx): {total_projects}\n"
        f"- [Özet] Tamamlandı: {c_done} | Devam Ediyor: {c_prog} | İptal Edildi: {c_cancel}"
    )
    return summary
def load_dataset() -> pd.DataFrame:
    # Eski yükleyiciyi üzerine yaz: data/Projeler'den derle
    df = build_projects_df()
    return ensure_status_column(df)



def _maybe_answer_project_notes(user_text: str) -> str | None:
    """'X projesinin toplantı notları nelerdir' sorusunu deterministik yanıtlar (tekrarları korur)."""
    if not user_text:
        return None
    t = (user_text or "").strip()
    # Regex: "<Proje Adı> projesinin toplantı notları nelerdir"
    m = re.search(r"(?i)^\s*(.+?)\s+projesinin\s+toplantı\s*notları\s*nelerdir\s*\??\s*$", t, re.UNICODE)
    if not m:
        return None
    proj_name_asked = m.group(1).strip()

    # Dataset yükle
    df = load_dataset()
    if df is None or df.empty:
        return "Bu proje için kayıt bulunamadı."

    # Sütun isimleri
    cols = [c for c in df.columns]
    name_col = next((c for c in cols if "proje adı" in c.lower()), "Proje Adı")
    notes_col = next((c for c in cols if "not" in c.lower()), "Toplantı Notları")

    # Proje adı eşleşmesi (birebir, küçük/büyük harf farkını ve boşlukları normalize ederek)
    def norm(s: str) -> str:
        return (s or "").strip().lower().replace("\\u200b","").replace("\\xa0"," ")

    asked_norm = norm(proj_name_asked)
    mask = df[name_col].astype(str).apply(lambda x: norm(x) == asked_norm)
    sub = df.loc[mask]
    if sub.empty:
        # Yakın eşleşme: startswith
        mask2 = df[name_col].astype(str).apply(lambda x: norm(x).startswith(asked_norm))
        sub = df.loc[mask2]

    if sub.empty:
        return f"'{proj_name_asked}' adlı proje bulunamadı."

    # Notları satırlara böl ve tekrarları koruyarak sırala
    all_notes: list[str] = []
    for notes in sub[notes_col].dropna().astype(str).tolist():
        parts = [p.strip() for p in notes.split("\\n") if p.strip()]
        # Başındaki '-' veya madde işareti varsa temizle
        parts = [re.sub(r"^[\\-•\\*\\s]+", "", p) for p in parts]
        all_notes.extend(parts)

    if not all_notes:
        return f"{proj_name_asked} projesi için toplantı notu bulunamadı."

    lines = ["- " + n for n in all_notes]
    return "\\n".join(lines)

def _to_plain_answer(_s: str) -> str:
    if not isinstance(_s, str):
        return str(_s)
    t = _s.strip()
    # LLM bölümlü başlıklar ekliyorsa cevap bölümünü çıkarın; aksi takdirde olduğu gibi döndürün
    for pat in [r"(?is)^\s*yanıt\s*:?\s*(.*?)\n\s*(?:aksiyonlar|kaynaklar)\s*:",
                r"(?is)^\s*\*\*yanıt\*\*\s*:?\s*(.*?)\n\s*(?:\*\*aksiyonlar\*\*|\*\*kaynaklar\*\*)"]:
        m = _re.search(pat, t)
        if m and m.group(1).strip():
            return m.group(1).strip()
    # Varsa bölüm başlıklarını sil
    t = _re.sub(r"(?im)^\s*(?:yanıt|aksiyonlar|kaynaklar)\s*:?\s*$", "", t)
    t = _re.sub(r"(?im)^\s*\*\*(?:yanıt|aksiyonlar|kaynaklar)\*\*\s*:?\s*$", "", t)
    t = _re.split(r"(?im)^\s*(?:aksiyonlar|kaynaklar)\s*:", t)[0]
    t = _re.split(r"(?im)^\s*\*\*(?:aksiyonlar|kaynaklar)\*\*\s*:", t)[0]
    return t.strip()


st.set_page_config(page_title=config.APP_TITLE, page_icon="📊", layout="wide")

# Başlık aralığı için ufak CSS + sidebar collapse kapatma ui.sidebar_nav içinde
st.markdown("""
<style>
h1, .stMarkdown h1 { margin-top: 0.2rem !important; }
</style>
""", unsafe_allow_html=True)

# ====== Yardımcı ======

# ---- Proje Durumu Yardımcıları ----
STATUS_COL = "Proje Durumu"
STATUS_ALLOWED = ["İptal Edildi", "Tamamlandı", "Devam Ediyor"]
STATUS_COLORS = {
    "İptal Edildi": {"bg":"#ffe4e6","border":"#ef4444","text":"#ef4444"},
    "Tamamlandı":   {"bg":"#dcfce7","border":"#22c55e","text":"#16a34a"},
    "Devam Ediyor": {"bg":"#dbeafe","border":"#3b82f6","text":"#2563eb"},
}

def ensure_status_column(df: pd.DataFrame) -> pd.DataFrame:
    import numpy as np
    if STATUS_COL not in df.columns:
        np.random.seed(42)
        df[STATUS_COL] = np.random.choice(STATUS_ALLOWED, size=len(df))
    else:
        mask = df[STATUS_COL].isna() | (df[STATUS_COL].astype(str).str.strip()=="")
        if mask.any():
            fill_vals = np.random.choice(STATUS_ALLOWED, size=mask.sum())
            df.loc[mask, STATUS_COL] = fill_vals
    return df

def save_status_change(row_index: int, new_status: str) -> None:
    try:
        df_view = load_dataset()
        if 0 <= row_index < len(df_view):
            xlsx_path = df_view.iloc[row_index]["_excel_path"]
            import pandas as pd
            dfx = pd.read_excel(xlsx_path)
            # Proje Durumu sütununu bulun/kontrol edin
            durum_col = next((c for c in dfx.columns if "Durum" in str(c)), None)
            if durum_col is None:
                dfx["Proje Durumu"] = new_status
            else:
                # Tüm sütunu yeni durumla doldurun (başlık satırları hariç)
                dfx[durum_col] = new_status
            dfx.to_excel(xlsx_path, index=False)
    except Exception as e:
        st.error(f"Durum kaydetme hatası: {e}")
    else:
        return pd.DataFrame(columns=["Proje Adı","Toplantı Konusu","Toplantı Tarihleri","Toplantı Notları","Proje Dokümanları"])


def _maybe_handle_count_question(user_text: str) -> str | None:
    """Belirli sayım sorularını (örn. 'toplam kaç proje var') Excel'den deterministik yanıtlar.
    Format: Yanıt / Aksiyonlar / Kaynaklar.
    """
    if not user_text:
        return None
    t = user_text.strip().lower()
    keywords = ["kaç proje", "toplam kaç proje", "toplam proje", "kaç tane proje", "proje sayısı", "proje sayisi"]
    if any(k in t for k in keywords):
        # Excel'den sayımı yap
        try:
            import pandas as pd
            # Projeler klasöründeki Excel sayısını say
            import glob, os
            folder = config.PROJELER_DIR
            files = glob.glob(os.path.join(folder, "*.xlsx"))
            total = len(files)
            # Yanıt formatı
            answer = f"Toplam {total} proje bulunmaktadır."
            aksiyon = "Hiç aksi bir işlem gerekmez."
            kaynak = "ProjectBot_Dataset_100.xlsx – satır sayımı"
            return f"{answer}\n\nAksiyonlar\n\n{aksiyon}\n\nKaynaklar\n\n{kaynak}"
        except Exception as e:
            return f"[Hata] Proje sayısı okunamadı: {e}"
    return None


def ensure_embedding_notice():
    if not os.path.isdir(config.EMBED_MODEL_PATH):
        st.warning(
            f"Embedding modeli bulunamadı: {config.EMBED_MODEL_PATH}.\n"
            f"Lütfen paraphrase-multilingual-MiniLM-L12-v2 klasörünü Embedding/ içine kopyalayın ve uygulamayı yeniden başlatın."
        )

# ====== Sol Navigasyon (sabit) ======
ui.sidebar_nav()
ui.horizontal_rule()

# ====== Sohbetler listesi (sol sekme) ======
st.sidebar.markdown("**💬 Sohbetler**")
store = ConversationStore()
threads = store.list_threads()

# Yeni sohbet oluştur butonu (her zaman görünür)
if st.sidebar.button("Yeni Sohbet ✚", use_container_width=True):
    tid = store.new_thread()
    st.session_state["current_thread_id"] = tid
    st.session_state["rename_id"] = None
    st.rerun()

# Mevcut sohbetler (seçme, silme, yeniden adlandırma)
for t in threads:
    row = st.sidebar.container()
    cols = row.columns([0.65, 0.17, 0.18])
    if cols[0].button(t["title"], key=f"open_{t['id']}", use_container_width=True):
        st.session_state["current_thread_id"] = t["id"]
        st.session_state["rename_id"] = None
        st.rerun()
    # Düzenle (✎ tuşu ikinci kez basılırsa alanı kapat)
    if cols[1].button("✎", key=f"edit_{t['id']}"):
        if st.session_state.get("rename_id") == t["id"]:
            st.session_state["rename_id"] = None
        else:
            st.session_state["rename_id"] = t["id"]
            st.session_state["rename_text"] = t["title"]
    # Sil
    if cols[2].button("✖", key=f"del_{t['id']}"):
        store.delete_thread(t["id"])
        if st.session_state.get("current_thread_id") == t["id"]:
            st.session_state["current_thread_id"] = None
        st.session_state["rename_id"] = None
        st.rerun()

    # Yeniden adlandırma alanı
    if st.session_state.get("rename_id") == t["id"]:
        new_name = st.sidebar.text_input(
            "Sohbet adını düzenle",
            key=f"name_input_{t['id']}",
            value=st.session_state.get("rename_text", t["title"]),
            label_visibility="collapsed"
        )
        cc1, cc2 = st.sidebar.columns([0.5, 0.5])
        if cc1.button("Kaydet", key=f"save_{t['id']}", use_container_width=True):
            data = store._read()
            for th in data.get("threads", []):
                if th["id"] == t["id"]:
                    th["title"] = new_name.strip() or th["title"]
                    break
            store._write(data)
            st.session_state["rename_id"] = None
            st.rerun()
        if cc2.button("Vazgeç", key=f"cancel_{t['id']}", use_container_width=True):
            st.session_state["rename_id"] = None
            st.rerun()


st.sidebar.markdown("---")
# --- 📅 Toplantı Takvimi (butonun hemen altında) ---
try:
    _df_all_for_calendar = load_dataset()
except Exception:
    _df_all_for_calendar = None

import calendar as _cal
from datetime import datetime as _dt

st.sidebar.markdown("### 📅 Toplantı Takvimi")
# --- 🗓️ Aylık Ajanda (Dropdown) ---
try:
    _agenda_records = build_meeting_records()
except Exception:
    _agenda_records = []

# Ay seçeneklerini "YYYY - Ay" formatında çıkar
_TR_MONTHS = ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"]
_month_keys = sorted({ (rec["year"], rec["month"]) for rec in _agenda_records })
_month_labels = [ f"{y} - {_TR_MONTHS[m-1]}" for (y,m) in _month_keys ]

_default_idx = len(_month_keys) - 1
# Varsayılanı mevcut aya eşitle (varsa)
try:
    _now_y, _now_m = _dt.now().year, _dt.now().month
    if (_now_y, _now_m) in _month_keys:
        _default_idx = _month_keys.index((_now_y, _now_m))
except Exception:
    pass

_now = _dt.now()
_fallback_label = f"{_now.year} - {_TR_MONTHS[_now.month-1]}"
_selected_month_label = st.sidebar.selectbox("Aylık Ajanda", _month_labels if _month_labels else [_fallback_label], index=_default_idx if _month_labels else 0)
_selected_year, _selected_month = None, None
if _month_labels:
    _selected_year, _selected_month = _month_keys[_month_labels.index(_selected_month_label)]
st.sidebar.caption("Seçtiğiniz aya ait toplantılar burada listelenir.")
# --- Seçilen Aya Ait Ajanda (Sidebar Liste) ---
try:
    _agenda_records = build_meeting_records()
except Exception:
    _agenda_records = []

if _agenda_records and _selected_year and _selected_month:
    _TR_MONTHS = ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"]
    _title_sb = f"**{_TR_MONTHS[_selected_month-1]} {_selected_year} – Aylık Ajanda**"
    st.sidebar.markdown(_title_sb)
    _items_sb = [r for r in _agenda_records if r["year"] == _selected_year and r["month"] == _selected_month]
    _items_sb.sort(key=lambda r: (r["date"], r["project"], r.get("topic","")))
    color_map = {
        "İptal Edildi": STATUS_COLORS.get("İptal Edildi", {}).get("text", "#ef4444"),
        "Tamamlandı":   STATUS_COLORS.get("Tamamlandı", {}).get("text", "#16a34a"),
        "Devam Ediyor": STATUS_COLORS.get("Devam Ediyor", {}).get("text", "#2563eb"),
    }
    if _items_sb:
        for rec in _items_sb:
            _date_html = rec["date_str"]
            _status = str(rec.get("status","")).strip()
            if _status not in STATUS_ALLOWED and _status:
                if "tamam" in _status.lower(): _status = "Tamamlandı"
                elif "iptal" in _status.lower(): _status = "İptal Edildi"
                else: _status = "Devam Ediyor"
            color = color_map.get(_status, "#2563eb")
            _line = f"<span style='font-weight:600;color:{color}'>{_date_html}</span> – {rec['topic']}"
            st.sidebar.markdown(_line, unsafe_allow_html=True)
    else:
        st.sidebar.info("Bu ay için toplantı bulunamadı.")

_now = _dt.now()
_y, _m = _now.year, _now.month

# Tüm projelerdeki "Toplantı Tarihleri" hücrelerinden tarihleri topla
_meeting_days = set()
def _parse_date_token(_s: str):
    _s = str(_s).strip()
    if not _s or _s.lower() in ("nan","nat","none","null"):
        return None
    # GG.AA.YYYY
    m1 = re.match(r"^(\d{2})\.(\d{2})\.(\d{4})$", _s)
    if m1:
        d, m, y = map(int, m1.groups())
        return (y, m, d)
    # YYYY-AA-GG veya YYYY-MM-DD
    m2 = re.match(r"^(\d{4})[-/.](\d{2})[-/.](\d{2})$", _s)
    if m2:
        y, m, d = map(int, m2.groups())
        return (y, m, d)
    # Son çare: pandas ile dene (dayfirst=True)
    try:
        import pandas as _pd
        ts = _pd.to_datetime(_s, dayfirst=True, errors="coerce")
        if _pd.isna(ts):
            return None
        return (int(ts.year), int(ts.month), int(ts.day))
    except Exception:
        return None

if _df_all_for_calendar is not None and len(_df_all_for_calendar)>0 and "Toplantı Tarihleri" in _df_all_for_calendar.columns:
    for _cell in _df_all_for_calendar["Toplantı Tarihleri"].fillna("").astype(str).tolist():
        # parçala: | , veya yeni satır
        for _tok in re.split(r"[|,\n]+", _cell):
            _tok = _tok.strip()
            if not _tok: 
                continue
            parsed = _parse_date_token(_tok)
            if parsed and parsed[0] == _y and parsed[1] == _m:
                _meeting_days.add(parsed[2])

# Ay başlığını TR biçiminde yaz
_TR_MONTHS = ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"]


_calobj = _cal.Calendar(firstweekday=0)  # Pazartesi=0? Python'da varsayılan Pazartesi


ui.horizontal_rule()

# ====== Sayfa Mantığı ======
page = st.session_state.get("page", config.BOT_PAGE_TITLE)

# ====== Project Bot (Chat) ======


if page == config.BOT_PAGE_TITLE:
    # --- Proje Bot sayfasında başlık aralıklarını daraltın ---
    st.markdown("""
<style>
/* Slightly reduce the top padding of the main block for a tighter header look */
div.block-container { padding-top: 0.6rem; }
/* Make h1 titles hug the top a bit more */
section.main h1 { margin-top: 0.1rem; margin-bottom: 0.35rem; }
</style>
""", unsafe_allow_html=True)

    # Başlık ve minimal üst çizgi
    st.title(config.BOT_PAGE_TITLE)
    st.markdown("<hr style='margin-top:0.2rem'/>", unsafe_allow_html=True)

    # Sol menü
    try:
        pass
    except Exception:
        pass

    store = ConversationStore()
    thread_id = st.session_state.get("current_thread_id")
    thread = store.get_thread(thread_id) if thread_id else {"messages": []}

    
    # --- Geçmişi (sohbet mesajları) göster ---
    if thread_id:
        thread = store.get_thread(thread_id) or {"messages": []}
        for msg in thread.get("messages", []):
            role = "assistant" if msg.get("role") == "assistant" else "user"
            with st.chat_message(role):
                st.markdown(msg.get("content", ""))
    
# --- Kullanıcı girişi ---
    prompt = st.chat_input("Sorunuzu yazın ve Enter'a basın…")
    if prompt:
        # Basit konu filtreleme: proje dışı yaygın anahtar kelimeleri saptayıp modele yönerge ekle
        _non_project_keywords = ["hava nasıl", "döviz", "bitcoin", "futbol", "siyaset", "seçim", "sağlık", "yemek tarifi", "film öner"]
        if any(k in prompt.lower() for k in _non_project_keywords):
            prompt = "[KAPSAM UYARISI: Sadece proje/proje kartı sorularına yanıt ver; konu dışına çıkma.] " + prompt
        # İlk mesajda sohbet oluştur
        if not thread_id:
            st.session_state.current_thread_id = store.new_thread()
            thread_id = st.session_state.current_thread_id
            thread = store.get_thread(thread_id) or {"messages": []}
        # Soru hemen ekranda gösterilsin
        with st.chat_message("user"):
            st.markdown(prompt)

        # Kayda al
        store.add_message(thread_id, "user", prompt)
        try:
            store.set_title_if_empty(thread_id, prompt, max_words=getattr(config, "AUTOTITLE_MAX_WORDS", 10))
        except Exception:
            pass

        # --- Bağlam (RAG) ---
        try:
            hits = rag.search(prompt, top_k=getattr(config, "TOP_K", 5))
            ctx = "\n\n".join([f"- {h.get('text','')}" for h in (hits or [])])
            # Dataset özeti + kural: proje sayısı = proje kartı sayısı = dataset satır sayısı
            try:
                _df = load_dataset()
                _ds_count = len(_df) if _df is not None else None
                if _ds_count is not None:
                    _ds_name = 'Projeler klasörü (toplam dosya sayısı)'; _ds_count = len([p for p in PROJELER_DIR.glob('*.xlsx')])
                    rule = "- [Kural] Proje sayısı = Proje kartı sayısı = dataset satır sayısı (her satır tek bir proje kartıdır)."
                    count_info = f"- [Dataset Bilgisi] {_ds_name} satır sayısı: {_ds_count}"
                    ctx = (ctx + "\n\n" if ctx else "") + rule + "\n" + count_info
            except Exception:
                pass

        except Exception as e:
            ctx = ""
            import config
            if getattr(config, "SHOW_RAG_WARNINGS", False):
                st.caption(f"RAG bağlamı oluşturulamadı: {e}")


        # --- Otomatik Proje Özeti (Projeler klasöründen) ---
        try:
            df_proj = build_projects_df()
            total_projects = int(len(df_proj)) if df_proj is not None else 0
            # Statü dağılımı
            status_col = "Proje Durumu"
            status_counts = {}
            status_list = []
            if df_proj is not None and status_col in df_proj.columns:
                for s_, n_ in df_proj[status_col].fillna("").astype(str).str.strip().replace({"nan":"", "None":"", "NaT":""}).value_counts().items():
                    key = s_ if s_ else "Bilinmiyor"
                    status_counts[key] = int(n_)
                status_list = list(status_counts.keys())
            # Proje adları
            proj_names = df_proj["Proje Adı"].dropna().astype(str).tolist() if (df_proj is not None and "Proje Adı" in df_proj.columns) else []

            summary_lines = [
                "[Yerel Özet]",
                f"- Toplam Proje = {total_projects} (Proje Kartı sayısı ile aynıdır)",
                f"- Durumlar = {', '.join(status_list) if status_list else 'Bilinmiyor'}",
                f"- Durum Dağılımı = " + (", ".join([f"{k}: {v}" for k,v in status_counts.items()]) if status_counts else "Bilinmiyor"),
                f"- Proje Adları = {', '.join(proj_names[:50])}" + (" ..." if len(proj_names)>50 else ""),
            ]
            ctx = (ctx + "\n\n" if ctx else "") + "\n".join(summary_lines)
        except Exception as _e_summary:
            pass
        
    
        # --- Model çağrısı ve Akış ---
        
        # --- HİBRİT: "X projesinin toplantı notları nelerdir?" için LLM'e aynen yaz talimatı ile bağlam ekle ---
        _det_notes = _maybe_answer_project_notes(prompt)
        if _det_notes and _det_notes.strip():
            _forced = (
                "Aşağıda bir projenin toplantı notları, tekrarlar KORUNARAK çıkarılmıştır.\n"
                "LÜTFEN BU LİSTEYİ AYNEN, her madde ayrı satırda, başına '-' koyarak yaz. "
                "Başka hiçbir açıklama, özet, başlık, giriş veya kapanış ekleme.\n\n"
                f"{_det_notes}\n"
            )
            ctx = (ctx + "\n\n" + _forced).strip()

        user_prompt = (
            "Aşağıdaki bağlamı kullanarak soruyu yanıtla. "
            "Bağlam boşsa bildiğin kadar yanıtla ama varsayım yaptığını belirt.\n\n"
            f"BAĞLAM:\n{ctx}\n\nSORU:\n{prompt}"
        )

        messages = llm.build_chat_messages(SYSTEM_PROMPT, user_prompt)

        with st.chat_message("assistant"):
            acc = ""
            try:
                stream = llm.ollama_chat_stream(messages)
                placeholder = st.empty()
                for chunk in stream:
                    acc += chunk
                    placeholder.markdown(_to_plain_answer(acc))
            except Exception as e:
                acc += f"\n\n[Akış hatası] {e}"
                st.error(str(e))

        # Cevabı kaydet
        store.add_message(thread_id, "assistant", _to_plain_answer(acc))
        # İlk mesajdan sonra sohbetin hemen görünmesi için güvenli yeniden çalıştır
        if not st.session_state["first_msg_rerun_done"]:
            st.session_state["first_msg_rerun_done"] = True
            st.rerun()
elif page == config.CARDS_PAGE_TITLE:

    # --- Proje Kartları sayfasında başlık aralıklarını daraltın ---
    st.markdown("""
<style>
/* Slightly reduce the top padding of the main block for a tighter header look */
div.block-container { padding-top: 0.6rem; }
/* Make h1 titles hug the top a bit more */
section.main h1 { margin-top: 0.1rem; margin-bottom: 0.35rem; }
</style>
""", unsafe_allow_html=True)




    st.title(config.CARDS_PAGE_TITLE)
    ensure_embedding_notice()

    df = load_dataset()

    # En üstte yeni proje kartı 
    with st.expander("Yeni Proje Kartı Oluştur ✚", expanded=False):
        with st.form("new_project_form", clear_on_submit=True):
            c1, c2 = st.columns(2)
            proj_adi = c1.text_input("Proje Adı", value="")
            proj_konusu = c2.text_input("Toplantı Konusu", value="")
            toplantilar = st.text_area("Toplantı Tarihleri", value="", height=80, placeholder="Örn: 01.07.2025, 20.08.2025 ...")
            notlar = st.text_area("Toplantı Notları", value="", height=120)
            uploaded_docs = st.file_uploader("Proje Dokümanları", accept_multiple_files=True, type=None, help="Bir veya birden çok dosya seçin")
            submitted = st.form_submit_button("Kaydet ve Ekle", use_container_width=True)
            
            if submitted:
                proj_adi_norm = (proj_adi or "").strip()
                if not proj_adi_norm:
                    st.error("Proje Adı zorunludur.")
                    st.stop()
                    
                # 1) Yüklenen dokümanları kaydet
                save_dir = os.path.join(config.PROJE_DOKUMANLARI_DIR, proj_adi_norm)
                os.makedirs(save_dir, exist_ok=True)
                saved_files = []
                if uploaded_docs:
                    for _f in uploaded_docs:
                        try:
                            _dest = os.path.join(save_dir, _f.name)
                            with open(_dest, "wb") as out:
                                out.write(_f.getbuffer())
                            saved_files.append(_dest)
                        except Exception:
                            pass
                
                # 2) Proje kartını Excel'e yaz (data/Projeler/<Proje Adı>.xlsx)
                os.makedirs(config.PROJELER_DIR, exist_ok=True)
                xlsx_path = os.path.join(config.PROJELER_DIR, f"{proj_adi_norm}.xlsx")
                
                df_x, konu_col, tarih_col, not_col, durum_col = _read_project_excel(xlsx_path)
                new_row_excel = {
                    konu_col:   (proj_konusu or "").strip(),
                    tarih_col:  (toplantilar or "").strip(),  # metin alanındaki tarihler aynen yazılır
                    not_col:    (notlar or "").strip(),
                    durum_col:  "Devam Ediyor",               # varsayılan durum
                }
                df_x = pd.concat([df_x, pd.DataFrame([new_row_excel])], ignore_index=True)
                _write_project_excel(xlsx_path, df_x)
                
                # 3) (İsteğe bağlı) RAG/FAISS indeksini güncelle
                try:
                    # mevcut fonksiyon sadece yeniden inşa ettiği için direkt çağırabiliriz
                    from src import rag
                    rag.build_or_load_faiss(rebuild=True)
                    st.toast("Proje kartı eklendi ve FAISS indeksi güncellendi.", icon="✅")
                    st.rerun()
                except Exception as e:
                    st.error(f"Kaydetme/indeksleme hatası: {e}")
                    
    # --- Arama & Filtreleme (Proje Kartları üstünde) ---
    # 1) Başlık/caption satırı
    h1, h2, h3 = st.columns([0.70, 0.06, 0.24], gap="small")
    with h1:
        st.markdown("<div style='margin-bottom:5px;'><span style='color:white;'>Proje Adı ile Ara</span></div>", unsafe_allow_html=True)
    with h2:
        st.caption(" ")
    with h3:
        st.markdown("<div style='margin-bottom:5px;'><span style='color:white;'>Durum Filtresi</span></div>", unsafe_allow_html=True)

    # 2) Bileşen satırı
    c1, c2, c3 = st.columns([0.70, 0.06, 0.24], gap="small")
    with c1:
        _search_q = st.text_input("Proje Adı ile Ara",
                                  key="filter_search_name",
                                  placeholder="Proje adı yazın...",
                                  label_visibility="collapsed")
    with c2:
        _search_btn = st.button("🔍", key="filter_search_btn", use_container_width=True)
    with c3:
        _status_choice = st.selectbox("Durum Filtresi", ["Tümü"] + STATUS_ALLOWED,
                                      index=0, key="filter_status_choice",
                                      label_visibility="collapsed")
    # --- /Arama & Filtreleme ---
    # Filtreleri uygula
    _fdf = df.copy()
    if isinstance(_fdf, pd.DataFrame) and not _fdf.empty:
        if _search_q and str(_search_q).strip():
            _fdf = _fdf[_fdf["Proje Adı"].astype(str).str.contains(str(_search_q).strip(), case=False, na=False)]
        if _status_choice != "Tümü" and STATUS_COL in _fdf.columns:
            _fdf = _fdf[_fdf[STATUS_COL].astype(str) == _status_choice]
        df = _fdf.reset_index(drop=True)


# Toplam kart sayısı
    # Sayı özetleri
    total = len(df)
    c_cancel = int((df[STATUS_COL] == "İptal Edildi").sum()) if not df.empty else 0
    c_done   = int((df[STATUS_COL] == "Tamamlandı").sum()) if not df.empty else 0
    c_prog   = int((df[STATUS_COL] == "Devam Ediyor").sum()) if not df.empty else 0
    st.markdown(
    f"**Toplam Proje Kartı :** {total}"
    f"<span style='margin:0 12px;'>|</span>"
    f"<span style='color:{STATUS_COLORS['İptal Edildi']['text']}'>İptal Edilen:</span> {c_cancel}"
    f"<span style='margin:0 12px;'>|</span>"
    f"<span style='color:{STATUS_COLORS['Tamamlandı']['text']}'>Tamamlanan:</span> {c_done}"
    f"<span style='margin:0 12px;'>|</span>"
    f"<span style='color:{STATUS_COLORS['Devam Ediyor']['text']}'>Devam Eden:</span> {c_prog}"
    f"<span style='margin:0 12px;'>|</span>",
    unsafe_allow_html=True
)


    if df.empty:
        st.info("Henüz proje kartı bulunmuyor.")
    else:
        # Dört sütunlu grid
        for start in range(0, len(df), 4):
            cols = st.columns(4)
            for col_i, col in enumerate(cols):
                idx = start + col_i
                if idx >= len(df):
                    continue
                row = df.iloc[idx]

                # Her kart için toggle state
                flag_key = f"open_card_{idx}"
                if flag_key not in st.session_state:
                    st.session_state[flag_key] = False
                det_key_name = f"detail_key_{idx}"
                det_txt_name = f"detail_text_{idx}"
                if det_key_name not in st.session_state:
                    st.session_state[det_key_name] = None
                if det_txt_name not in st.session_state:
                    st.session_state[det_txt_name] = ""

                with col.container(border=True):
                    status = str(row.get(STATUS_COL, 'Devam Ediyor'))
                    colors = STATUS_COLORS.get(status, STATUS_COLORS['Devam Ediyor'])
                    st.markdown(f"<div style='height:6px; background:{colors['border']}; border-radius:6px; margin-bottom:6px;'></div>", unsafe_allow_html=True)
                    
                                        # --- Başlık + küçük düzenle/sil butonları (yan yana kare) ---
                    _title_cols = st.columns([0.60, 0.20, 0.20], gap="small")
                    with _title_cols[0]:
                        st.markdown(f"**{row.get('Proje Adı', 'İsimsiz Proje')}**")
                    # Düzenle (başlığı inline düzenlemek için text_input)
                    with _title_cols[1]:
                        _edit_key = f"edit_title_{idx}"
                        _rename_mode_key = f"rename_mode_{idx}"
                        if _rename_mode_key not in st.session_state:
                            st.session_state[_rename_mode_key] = False
                        if st.button("✎", key=_edit_key, help="Düzenle", use_container_width=True):
                            st.session_state[_rename_mode_key] = not st.session_state[_rename_mode_key]
                    with _title_cols[2]:
                        _del_key = f"del_card_{idx}"
                        if st.button("✖", key=_del_key, help="Kartı Sil", use_container_width=True):
                            try:
                                xlsx_path = str(row.get("_excel_path", ""))
                                if xlsx_path and os.path.exists(xlsx_path):
                                    os.remove(xlsx_path)
                                    st.toast("Proje kartı silindi.", icon="✅")
                                    st.rerun()
                                else:
                                    st.error("Silinecek dosya bulunamadı.")
                            except Exception as _e:
                                st.error(f"Silme hatası: {_e}")
                    
                    # İsim düzenleme alanı (aç/kapa)
                    if st.session_state.get(_rename_mode_key, False):
                        _new_name = st.text_input("Yeni proje adı", value=str(row.get("Proje Adı", "İsimsiz Proje")), key=f"rename_input_{idx}")
                        _save_cols = st.columns([0.5,0.5])
                        with _save_cols[0]:
                            if st.button("Kaydet", key=f"rename_save_{idx}", use_container_width=True):
                                try:
                                    new_title = (_new_name or "").strip()
                                    # 1) İç dosyada 'Proje Adı' kolonunu güncelle
                                    xlsx_path_old = str(row.get("_excel_path", ""))
                                    if xlsx_path_old:
                                        try:
                                            dfx = pd.read_excel(xlsx_path_old)
                                        except Exception:
                                            dfx = pd.DataFrame()
                                        if not dfx.empty:
                                            if "Proje Adı" in dfx.columns:
                                                dfx["Proje Adı"] = new_title or dfx["Proje Adı"]
                                                dfx.to_excel(xlsx_path_old, index=False)
                                        # 2) Dosya adını değiştir
                                        base_dir = os.path.dirname(xlsx_path_old)
                                        safe_name = new_title or os.path.splitext(os.path.basename(xlsx_path_old))[0]
                                        safe_name = safe_name.strip() or "Proje"
                                        xlsx_path_new = os.path.join(base_dir, f"{safe_name}.xlsx")
                                        if xlsx_path_new != xlsx_path_old:
                                            # Çakışmayı engelle: aynı isimliyse sonuna sayı ekle
                                            candidate = xlsx_path_new
                                            c = 2
                                            while os.path.exists(candidate):
                                                candidate = os.path.join(base_dir, f"{safe_name}-{c}.xlsx")
                                                c += 1
                                            os.replace(xlsx_path_old, candidate)
                                    # Formu kapat ve yenile
                                    st.session_state[_rename_mode_key] = False
                                    st.rerun()
                                except Exception as _e:
                                    st.error(f"Güncelleme hatası: {_e}")
                        with _save_cols[1]:
                            if st.button("Vazgeç", key=f"rename_cancel_{idx}", use_container_width=True):
                                st.session_state[_rename_mode_key] = False
                                st.rerun()

                                st.rerun()
                    st.markdown(f"<div style='display:inline-block; position:relative; top:-8px;'><span style=\"background:#1f2937; color:#ffffff; padding:2px 6px; border-radius:6px; font-size:12px;\">Durum :</span> <span style=\"color:{colors['text']}; font-size:12px; font-weight:600;\">{status}</span></div>", unsafe_allow_html=True)
                    # İstenen buton metni: Kart Detayları / Kapat
                    label = "Kart Detayları"
                    if st.button(label, key=f"btn_open_{idx}", use_container_width=True):
                        st.session_state[flag_key] = not st.session_state[flag_key]
                        if not st.session_state[flag_key]:
                            st.session_state[det_key_name] = None
                            st.session_state[det_txt_name] = ""

                    if st.session_state[flag_key]:
                        
                        with st.expander("Kart Detayları", expanded=True):
                            # Sadece istenen 5 buton (sıralı)
                            labels = ["Toplantı Konusu", "Toplantı Tarihleri", "Toplantı Notları", "Proje Dokümanları", "Proje Durumu"]
                            current = st.session_state.get(det_key_name)
                            for lab in labels:
                                if st.button(lab, key=f"btn_{lab}_{idx}", use_container_width=True):
                                    if current == lab:
                                        st.session_state[det_key_name] = None
                                        st.session_state[det_txt_name] = ""
                                    else:
                                        st.session_state[det_key_name] = lab
                                        st.session_state[det_txt_name] = str(row.get(lab, ""))
                            dk = st.session_state.get(det_key_name)
                            if dk:

                                    # Xlsx yolunu al
                                    xlsx_path = str(row.get("_excel_path", ""))
                                    df_x, konu_col, tarih_col, not_col, durum_col = _read_project_excel(xlsx_path)

                                    if dk == "Toplantı Konusu":
                                        st.markdown("**Mevcut Toplantı Konuları**")
                                        # Listele
                                        for ridx in range(len(df_x)):
                                            konu = str(df_x.iloc[ridx].get(konu_col, "")).strip()
                                            if not konu:
                                                continue
                                            cols = st.columns([0.70, 0.15, 0.15], gap='small')
                                            with cols[0]:
                                                st.markdown(f"- {konu}")
                                            with cols[1]:
                                                if st.button("✎", key=f"edit_konu_{idx}_{ridx}", use_container_width=True):
                                                    st.session_state[f"edit_konu_mode_{idx}_{ridx}"] = not st.session_state.get(f"edit_konu_mode_{idx}_{ridx}", False)
                                            with cols[2]:
                                                if st.button("✖", key=f"del_konu_{idx}_{ridx}", use_container_width=True):
                                                    # Tüm satırı sil
                                                    df_x = df_x.drop(df_x.index[ridx]).reset_index(drop=True)
                                                    _write_project_excel(xlsx_path, df_x)
                                                    st.rerun()
                                            if st.session_state.get(f"edit_konu_mode_{idx}_{ridx}", False):
                                                newv = st.text_input("Yeni konu", value=konu, key=f"konu_val_{idx}_{ridx}")
                                                _c1, _c2 = st.columns([0.5,0.5])
                                                with _c1:
                                                    if st.button("Kaydet", key=f"save_konu_{idx}_{ridx}", use_container_width=True):
                                                        df_x.at[ridx, konu_col] = newv.strip()
                                                        _write_project_excel(xlsx_path, df_x)
                                                        st.session_state[f"edit_konu_mode_{idx}_{ridx}"] = False
                                                        st.rerun()
                                                with _c2:
                                                    if st.button("Vazgeç", key=f"cancel_konu_{idx}_{ridx}", use_container_width=True):
                                                        st.session_state[f"edit_konu_mode_{idx}_{ridx}"] = False
                                                        st.rerun()

                                        st.divider()
                                        st.markdown("**Toplantı Konusu Ekle**")
                                        _new_topic_val = st.text_input("Yeni Toplantı Konusu", key=f"new_topic_{idx}")
                                        if st.button("Ekle", key=f"add_topic_{idx}") and _new_topic_val.strip():
                                            # Yeni satır ekle (konu dolu, tarih/not boş)
                                            new_row = {konu_col: _new_topic_val.strip(), tarih_col: "", not_col: "", durum_col: df_x.iloc[-1][durum_col] if not df_x.empty and durum_col in df_x.columns else ""}
                                            df_x = pd.concat([df_x, pd.DataFrame([new_row])], ignore_index=True)
                                            _write_project_excel(xlsx_path, df_x)
                                            st.rerun()

                                    elif dk == "Toplantı Tarihleri":
                                        st.markdown("**Mevcut Toplantı Tarihleri**")
                                        for ridx in range(len(df_x)):
                                            raw_t = df_x.iloc[ridx].get(tarih_col, "")
                                            if pd.isna(raw_t):
                                                continue
                                            tarih = str(raw_t).strip()
                                            if not tarih or tarih.lower() in ("nan","nat","none","null"):
                                                continue
                                            cols = st.columns([0.70, 0.15, 0.15], gap='small')
                                            with cols[0]:
                                                st.markdown(f"- {tarih}")
                                            with cols[1]:
                                                if st.button("✎", key=f"edit_tarih_{idx}_{ridx}", use_container_width=True):
                                                    st.session_state[f"edit_tarih_mode_{idx}_{ridx}"] = not st.session_state.get(f"edit_tarih_mode_{idx}_{ridx}", False)
                                            with cols[2]:
                                                if st.button("✖", key=f"del_tarih_{idx}_{ridx}", use_container_width=True):
                                                    # Sadece tarih hücresi temizlenir
                                                    df_x.at[ridx, tarih_col] = ""
                                                    _write_project_excel(xlsx_path, df_x)
                                                    st.rerun()
                                            if st.session_state.get(f"edit_tarih_mode_{idx}_{ridx}", False):
                                                _new_date = st.date_input("Yeni tarih", key=f"tarih_val_{idx}_{ridx}")
                                                _c1, _c2 = st.columns([0.5,0.5])
                                                with _c1:
                                                    if st.button("Kaydet", key=f"save_tarih_{idx}_{ridx}", use_container_width=True):
                                                        df_x.at[ridx, tarih_col] = _new_date.strftime("%d.%m.%Y")
                                                        _write_project_excel(xlsx_path, df_x)
                                                        st.session_state[f"edit_tarih_mode_{idx}_{ridx}"] = False
                                                        st.rerun()
                                                with _c2:
                                                    if st.button("Vazgeç", key=f"cancel_tarih_{idx}_{ridx}", use_container_width=True):
                                                        st.session_state[f"edit_tarih_mode_{idx}_{ridx}"] = False
                                                        st.rerun()

                                        st.divider()
                                        st.markdown("**Toplantı Tarihi Ekleme**")
                                        ok, msg = _assert_can_add_date(df_x, tarih_col, konu_col)
                                        if not ok:
                                            st.info(msg)
                                        else:
                                            _new_dt = st.date_input("Yeni toplantı tarihi", key=f"new_dt_{idx}")
                                            if st.button("Ekle", key=f"add_dt_{idx}"):
                                                df_x.at[len(df_x)-1, tarih_col] = _new_dt.strftime("%d.%m.%Y")
                                                _write_project_excel(xlsx_path, df_x)
                                                st.rerun()

                                    elif dk == "Toplantı Notları":
                                        st.markdown("**Mevcut Toplantı Notları**")
                                        # Her hücreyi ayrı blok olarak göster
                                        for ridx in range(len(df_x)):
                                            raw_notes = str(df_x.iloc[ridx].get(not_col, "") if not df_x.empty else "").strip()
                                            notes = _normalize_notes_cell(raw_notes)
                                            if not notes:
                                                continue
                                            konu_hdr = str(df_x.iloc[ridx].get(konu_col, "")).strip()
                                            st.caption(f"{konu_hdr} notları")
                                            for j, nt in enumerate(notes):
                                                cols = st.columns([0.70, 0.15, 0.15], gap='small')
                                                with cols[0]:
                                                    st.markdown(f"- {nt}")
                                                with cols[1]:
                                                    if st.button("✎", key=f"edit_note_{idx}_{ridx}_{j}", use_container_width=True):
                                                        st.session_state[f"edit_note_mode_{idx}_{ridx}_{j}"] = not st.session_state.get(f"edit_note_mode_{idx}_{ridx}_{j}", False)
                                                with cols[2]:
                                                    if st.button("✖", key=f"del_note_{idx}_{ridx}_{j}", use_container_width=True):
                                                        new_parts = [p for k,p in enumerate(notes) if k!=j]
                                                        df_x.at[ridx, not_col] = _join_notes(new_parts)
                                                        _write_project_excel(xlsx_path, df_x)
                                                        st.rerun()
                                                if st.session_state.get(f"edit_note_mode_{idx}_{ridx}_{j}", False):
                                                    newv = st.text_area("Yeni not", value=nt, key=f"note_val_{idx}_{ridx}_{j}", height=100)
                                                    _c1, _c2 = st.columns([0.5,0.5])
                                                    with _c1:
                                                        if st.button("Kaydet", key=f"save_note_{idx}_{ridx}_{j}", use_container_width=True):
                                                            new_parts = notes[:]
                                                            new_parts[j] = newv.strip()
                                                            df_x.at[ridx, not_col] = _join_notes(new_parts)
                                                            _write_project_excel(xlsx_path, df_x)
                                                            st.session_state[f"edit_note_mode_{idx}_{ridx}_{j}"] = False
                                                            st.rerun()
                                                    with _c2:
                                                        if st.button("Vazgeç", key=f"cancel_note_{idx}_{ridx}_{j}", use_container_width=True):
                                                            st.session_state[f"edit_note_mode_{idx}_{ridx}_{j}"] = False
                                                            st.rerun()
                                            st.markdown("---")
                                        st.markdown("**Toplantı Notu Ekle**")
                                        ok, msg = _assert_can_add_note(df_x, tarih_col, konu_col)
                                        if not ok:
                                            st.info(msg)
                                        else:
                                            _new_note = st.text_area("Yeni toplantı notu", key=f"new_note_{idx}", height=120)
                                            if st.button("Ekle", key=f"add_note_{idx}") and _new_note.strip():
                                                # En son tarihli satıra ekle
                                                last_idx = len(df_x)-1
                                                existing_parts = _normalize_notes_cell(df_x.iloc[last_idx].get(not_col, ""))
                                                existing_parts.append(_new_note.strip())
                                                df_x.at[last_idx, not_col] = _join_notes(existing_parts)
                                                _write_project_excel(xlsx_path, df_x)
                                                st.rerun()

                                    elif dk == "Proje Dokümanları":
                                        # Mevcut davranışı koru: dosyaları indirilebilir butonlar
                                        proj_name = str(row.get("Proje Adı", "İsimsiz Proje"))
                                        docs_dir = Path(config.PROJE_DOKUMANLARI_DIR) / proj_name
                                        docs_dir.mkdir(parents=True, exist_ok=True)
                                        st.markdown("**Mevcut Proje Dokümanları**")
                                        files = sorted([p for p in docs_dir.glob("*") if p.is_file()])
                                        if not files:
                                            st.info("Bu proje için henüz doküman bulunamadı.")
                                        for f in files:
                                            with open(f, "rb") as fh:
                                                st.download_button(f.name, fh, file_name=f.name, key=f"dl_{idx}_{f.name}")
                                        st.divider()
                                        st.markdown("**Proje Dokümanı Ekle**")
                                        up = st.file_uploader("Doküman yükle", key=f"up_{idx}")
                                        if up is not None:
                                            out = docs_dir / up.name
                                            with open(out, "wb") as fh:
                                                fh.write(up.read())
                                            st.success("Yüklendi.")
                                            st.rerun()

                                    elif dk == "Proje Durumu":
                                        durumlar = ["Devam Ediyor", "Tamamlandı", "İptal Edildi"]
                                        current = ""
                                        # En sık görüleni tahmini olarak göster
                                        if not df_x.empty and "Proje Durumu" in df_x.columns and df_x["Proje Durumu"].dropna().size>0:
                                            current = str(df_x["Proje Durumu"].dropna().astype(str).mode().iloc[0])
                                        sel = st.selectbox("Proje Durumu", durumlar, index=(durumlar.index(current) if current in durumlar else 0), key=f"durum_sel_{idx}")
                                        if st.button("Kaydet", key=f"durum_save_{idx}", use_container_width=True):
                                            if "Proje Durumu" not in df_x.columns:
                                                df_x["Proje Durumu"] = ""
                                            df_x["Proje Durumu"] = sel
                                            _write_project_excel(xlsx_path, df_x)
                                            st.toast("Proje durumu güncellendi.", icon="✅")
                                            st.rerun()