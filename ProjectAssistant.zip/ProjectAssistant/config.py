import os

APP_TITLE = "Project Assistant"
BOT_PAGE_TITLE = "Project Bot"
CARDS_PAGE_TITLE = "Project Cards"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
VECTOR_DIR = os.path.join(BASE_DIR, "vectorstore")
EMBED_DIR = os.path.join(BASE_DIR, "Embedding")

PROJELER_DIR = os.path.join(DATA_DIR, "Projeler")
PROJE_DOKUMANLARI_DIR = os.path.join(DATA_DIR, "Proje Dokümanları")
CONV_STORE_PATH = os.path.join(DATA_DIR, "conversations.json")


DATASET_FILENAME = None  

FAISS_INDEX_PATH = os.path.join(VECTOR_DIR, "index.faiss")
FAISS_META_PATH = os.path.join(VECTOR_DIR, "meta.pkl")

OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "gpt-oss:20b")

EMBED_MODEL_PATH = os.environ.get(
    "EMBED_MODEL_PATH",
    os.path.join(EMBED_DIR, "paraphrase-multilingual-MiniLM-L12-v2")
)

TOP_K = 5
CHUNK_SIZE = 900
CHUNK_OVERLAP = 150
MIN_CHARS_TO_CHUNK = 1200

AUTOTITLE_MAX_WORDS = 10

SHOW_RAG_WARNINGS = False

# Not listesi çıktısında LLM'e 'aynen yaz' talimatı eklensin mi?
ENFORCE_NOTES_EXACT = True
